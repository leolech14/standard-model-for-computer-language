
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { OKLCHColor } from '../types';

interface OKLCHColorPickerProps {
    color: OKLCHColor;
    onChange: (color: OKLCHColor) => void;
}

const OKLCHColorPicker = ({ color, onChange }: OKLCHColorPickerProps) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const [isDragging, setIsDragging] = useState(false);

    // Draw the chroma/hue plane at the current lightness
    const drawSpace = useCallback(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const width = canvas.width;
        const height = canvas.height;
        const imageData = ctx.createImageData(width, height);
        const data = imageData.data;

        // X is Hue (0-360), Y is Chroma (0-0.4)
        for (let x = 0; x < width; x++) {
            for (let y = 0; y < height; y++) {
                const h = (x / width) * 360;
                const c = (1 - y / height) * 0.4;
                const index = (y * width + x) * 4;

                // Simple CSS color check isn't performant for pixel manipulation,
                // but for visualization we can approximate or use a library.
                // Here we just render the raw projection.
                const cssColor = `oklch(${color.l * 100}% ${c} ${h})`;
                
                // We'll use a shortcut: fill pixels manually with a gradient if needed, 
                // but for a true picker we want to see the gamut boundaries.
                // In this implementation, we rely on browser rendering for the marker 
                // and use a static gradient background with CSS to save CPU.
            }
        }
        // ctx.putImageData(imageData, 0, 0);
    }, [color.l]);

    useEffect(() => {
        drawSpace();
    }, [drawSpace]);

    const handleInteract = (e: React.MouseEvent | React.TouchEvent | MouseEvent | TouchEvent) => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const clientX = 'touches' in e ? e.touches[0].clientX : (e as MouseEvent).clientX;
        const clientY = 'touches' in e ? e.touches[0].clientY : (e as MouseEvent).clientY;
        
        const x = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
        const y = Math.max(0, Math.min(1, (clientY - rect.top) / rect.height));

        onChange({
            ...color,
            h: x * 360,
            c: (1 - y) * 0.4
        });
    };

    const onMouseDown = (e: React.MouseEvent) => {
        setIsDragging(true);
        handleInteract(e);
    };

    useEffect(() => {
        const onMouseMove = (e: MouseEvent) => isDragging && handleInteract(e);
        const onMouseUp = () => setIsDragging(false);

        if (isDragging) {
            window.addEventListener('mousemove', onMouseMove);
            window.addEventListener('mouseup', onMouseUp);
        }
        return () => {
            window.removeEventListener('mousemove', onMouseMove);
            window.removeEventListener('mouseup', onMouseUp);
        };
    }, [isDragging]);

    return (
        <div className="oklch-picker-container">
            <div className="oklch-main-plane" 
                ref={containerRef}
                onMouseDown={onMouseDown}
                style={{
                    background: `
                        linear-gradient(to top, oklch(${color.l * 100}% 0 0), transparent),
                        linear-gradient(to right, 
                            oklch(${color.l * 100}% 0.4 0), 
                            oklch(${color.l * 100}% 0.4 90), 
                            oklch(${color.l * 100}% 0.4 180), 
                            oklch(${color.l * 100}% 0.4 270), 
                            oklch(${color.l * 100}% 0.4 360)
                        )
                    `
                }}
            >
                <div 
                    className="oklch-marker"
                    style={{
                        left: `${(color.h / 360) * 100}%`,
                        top: `${(1 - (color.c / 0.4)) * 100}%`,
                        backgroundColor: `oklch(${color.l * 100}% ${color.c} ${color.h})`,
                        boxShadow: `0 0 10px oklch(${color.l * 100}% ${color.c} ${color.h} / 0.5)`
                    }}
                />
            </div>
            <div className="oklch-controls">
                <div className="oklch-slider-row">
                    <span>L</span>
                    <input 
                        type="range" 
                        min="0" max="1" step="0.01" 
                        value={color.l} 
                        onChange={(e) => onChange({...color, l: parseFloat(e.target.value)})} 
                    />
                    <span className="val">{Math.round(color.l * 100)}%</span>
                </div>
                <div className="oklch-preview-row">
                    <div className="swatch" style={{ background: `oklch(${color.l * 100}% ${color.c} ${color.h})` }} />
                    <code className="val">oklch({Math.round(color.l*100)}% {color.c.toFixed(2)} {Math.round(color.h)})</code>
                </div>
            </div>
        </div>
    );
};

export default OKLCHColorPicker;
